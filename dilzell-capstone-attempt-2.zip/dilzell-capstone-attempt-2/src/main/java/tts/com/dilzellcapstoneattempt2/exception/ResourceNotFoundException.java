package tts.com.dilzellcapstoneattempt2.exception;

public class ResourceNotFoundException extends Throwable {
    public ResourceNotFoundException(String s) {
    }
}
