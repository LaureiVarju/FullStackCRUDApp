package tts.com.dilzellcapstoneattempt2.exception;

public class GlobalExceptionHandler {
}
